TRABAJO FIN DE MASTER:
MASTER EN DATA SCIENCE I - KSCHOOL
Autor: David GM
____________________________________


Descripci�n de los ficheros del TFM:

Datos de entrada:
- Sales.csv: 	Fichero con los datos de las ventas de la empresa en 2015.
- Customer.csv: Informaci�n de los clientes de la empresa.

Proyecto:
- TFM_David_GM.Rmd:		C�digo del proyecto realizado en R.
- TFM_David_GM.html:	Resultado del proyecto en formato html.

Datos de Salida:
- RFM_EXTENDED_4clusters.csv:	Fichero generado con datos ya tratados para ser visualizados en Tableau.
- RFM_EXTENDED.tde: 			Fichero de datos exportado de Tableau.

Visualizaci�n:
- RFM_EXTENDED_4clusters.twb:	Dashboard interactivo de Tableau.
- RFM_EXTENDED_4clusters.twbx:	Dashboard interactivo de Tableau con los datos empaquetados. Se puede visualizar con Tableau Reader.